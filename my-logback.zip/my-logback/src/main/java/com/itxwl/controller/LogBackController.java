package com.itxwl.controller;

import com.itxwl.annotation.XwlLog;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author xueWenLiang
 * @date 2021/5/10 14:57
 * @Description 描述信息
 */
@RestController
@RequestMapping("my")
@AllArgsConstructor
public class LogBackController {

    private final Logger logger = LoggerFactory.getLogger(LogBackController.class);

    @GetMapping("testError")
    @XwlLog(describution = "测试")
    public Object testError(@RequestParam(value = "number",required = true) Integer number){
        logger.info("进入测试方法->");
        int x=0;
        try {
             x=5/number;
        } catch (Exception e) {
            logger.error("测试失败->信息体+"+number+",异常信息{"+e.getMessage()+"}");
        }
        return (Object) x;
    }



}
